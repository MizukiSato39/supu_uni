
  # Create blog site design

  This is a code bundle for Create blog site design. The original project is available at https://www.figma.com/design/knZpT2PmLN1g0xFhBx9V1m/Create-blog-site-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  