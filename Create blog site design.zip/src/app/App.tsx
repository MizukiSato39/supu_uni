import { useState, useMemo } from "react";
import { IzakayaHeader } from "./components/izakaya-header";
import { IzakayaBreadcrumb } from "./components/izakaya-breadcrumb";
import { IzakayaBlogHeader } from "./components/izakaya-blog-header";
import { IzakayaTagFilter } from "./components/izakaya-tag-filter";
import { IzakayaPostRow } from "./components/izakaya-post-card";
import { IzakayaSidebar } from "./components/izakaya-sidebar";
import { IzakayaFooter } from "./components/izakaya-footer";
import { blogConfig, blogPosts, getAllTags, formatDate } from "./data/blog-data";

const PROFILE_IMAGE =
  "https://images.unsplash.com/photo-1609559376775-38cdfa504de1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMGNoZWYlMjBwb3J0cmFpdCUyMGNvb2tpbmd8ZW58MXx8fHwxNzcxNDU3NDE2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

export default function App() {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const allTags = useMemo(() => getAllTags(blogPosts), []);

  const filteredPosts = useMemo(() => {
    if (!selectedTag) return blogPosts;
    return blogPosts.filter((post) => post.tags.includes(selectedTag));
  }, [selectedTag]);

  const latestDate = formatDate(blogPosts[0].date);

  const handleSelectTag = (tag: string | null) => {
    setSelectedTag(tag);
  };

  const isNewPost = (dateStr: string) => {
    const postDate = new Date(dateStr);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return postDate > weekAgo;
  };

  return (
    <div className="izakaya-page">
      <div className="izakaya-outer">
        {/* ヘッダー */}
        <IzakayaHeader />

        {/* 2カラムレイアウト */}
        <div className="izakaya-body">
          {/* 左サイドバー */}
          <IzakayaSidebar
            posts={blogPosts}
            allTags={allTags}
            onSelectTag={handleSelectTag}
            profileImage={PROFILE_IMAGE}
          />

          {/* メインコンテンツ */}
          <div className="izakaya-main">
            <IzakayaBreadcrumb blogTitle={blogConfig.blogTitle} />

            <IzakayaBlogHeader
              config={blogConfig}
              postCount={blogPosts.length}
              latestDate={latestDate}
            />

            <IzakayaTagFilter
              tags={allTags}
              selectedTag={selectedTag}
              onSelectTag={handleSelectTag}
            />

            {/* 記事一覧 */}
            <div>
              <div className="izakaya-section-head">
                ■ 日記一覧（{filteredPosts.length}件）
                {selectedTag && (
                  <span style={{ fontWeight: "normal", fontSize: 10, marginLeft: 6 }}>
                    ― 「{selectedTag}」で絞り込み中
                  </span>
                )}
              </div>

              {filteredPosts.length > 0 ? (
                <table className="izakaya-post-table">
                  <thead>
                    <tr>
                      <th>日付</th>
                      <th>タイトル</th>
                      <th>カテゴリ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPosts.map((post) => (
                      <IzakayaPostRow
                        key={post.id}
                        post={post}
                        onSelectTag={handleSelectTag}
                        isNew={isNewPost(post.date)}
                      />
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="izakaya-no-result">
                  該当する記事がありません。
                </div>
              )}
            </div>
          </div>
        </div>

        {/* フッター */}
        <IzakayaFooter />
      </div>
    </div>
  );
}
