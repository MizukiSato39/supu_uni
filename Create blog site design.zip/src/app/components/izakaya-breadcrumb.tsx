interface BreadcrumbProps {
  blogTitle: string;
}

export function IzakayaBreadcrumb({ blogTitle }: BreadcrumbProps) {
  return (
    <div className="izakaya-breadcrumb">
      <a href="#">トップ</a>
      &gt;
      <a href="#">ブログ</a>
      &gt;
      {blogTitle}
    </div>
  );
}
