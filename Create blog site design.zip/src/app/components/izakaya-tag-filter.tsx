interface TagFilterProps {
  tags: string[];
  selectedTag: string | null;
  onSelectTag: (tag: string | null) => void;
}

export function IzakayaTagFilter({ tags, selectedTag, onSelectTag }: TagFilterProps) {
  return (
    <div className="izakaya-tag-filter">
      <div className="izakaya-tag-filter-title">■ カテゴリで絞り込む</div>
      <div className="izakaya-tag-buttons">
        <button
          className={`izakaya-tag-btn ${selectedTag === null ? "active" : ""}`}
          onClick={() => onSelectTag(null)}
        >
          [すべて]
        </button>
        {tags.map((tag) => (
          <button
            key={tag}
            className={`izakaya-tag-btn ${selectedTag === tag ? "active" : ""}`}
            onClick={() => onSelectTag(tag)}
          >
            [{tag}]
          </button>
        ))}
      </div>
    </div>
  );
}
