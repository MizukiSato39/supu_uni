import { useRef, useEffect } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const BANNER_IMAGE =
  "https://images.unsplash.com/photo-1704135489566-3929fc2a4fec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMGl6YWtheWElMjBsYW50ZXJuJTIwbmlnaHQlMjBzdHJlZXR8ZW58MXx8fHwxNzcxNDU3ODE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

const MARQUEE_TEXT =
  "★☆★ ようこそ！スプリング☆ユニバースへ！居酒屋めぐり・グルメ・旅行・宇宙のことなど気ままに綴っています♪ お気軽にコメントくださいね(ﾟ∀ﾟ)ノ ★☆★ 最新記事更新しました！ ★☆★ キリ番5000踏んだ方はご連絡ください！ ★☆★ 相互リンク募集中です♪ ★☆★";

function Marquee({ text }: { text: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    const textEl = textRef.current;
    if (!container || !textEl) return;

    let pos = container.offsetWidth;
    const textWidth = textEl.offsetWidth;
    let animId: number;

    const step = () => {
      pos -= 1.5;
      if (pos < -textWidth) {
        pos = container.offsetWidth;
      }
      textEl.style.transform = `translateX(${pos}px)`;
      animId = requestAnimationFrame(step);
    };

    animId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div ref={containerRef} className="izakaya-marquee">
      <span
        ref={textRef}
        style={{ display: "inline-block", whiteSpace: "nowrap" }}
      >
        {text}
      </span>
    </div>
  );
}

export function IzakayaHeader() {
  return (
    <div className="izakaya-header-banner">
      {/* 横長バナー画像 */}
      <ImageWithFallback
        src={BANNER_IMAGE}
        alt="スプリング☆ユニバース"
        className="izakaya-header-img"
      />

      {/* タイトル */}
      <div className="izakaya-header-top">
        <div>
          <div className="izakaya-header-title">
            スプリング☆ユニバース
          </div>
          <div className="izakaya-header-subtitle">
            ～宇宙の片隅の居酒屋ブログ～
          </div>
        </div>
      </div>

      {/* マーキー（JS制御で確実にスクロール） */}
      <Marquee text={MARQUEE_TEXT} />

      {/* ナビ */}
      <div className="izakaya-header-nav">
        <a href="#">トップ</a>
        <a href="#">日記</a>
        <a href="#">プロフィール</a>
        <a href="#">オークション</a>
        <a href="#">掲示板</a>
        <a href="#">ブログリンク</a>
      </div>
    </div>
  );
}
