import type { BlogPost } from "../data/blog-data";

interface PostCardProps {
  post: BlogPost;
  onSelectTag: (tag: string) => void;
  isNew?: boolean;
}

export function IzakayaPostRow({ post, onSelectTag, isNew }: PostCardProps) {
  return (
    <tr className="izakaya-post-row">
      <td className="izakaya-td-date">
        {post.date}
      </td>
      <td>
        <div className="izakaya-td-title">
          <a href="#">{post.emoji} {post.title}</a>
          {isNew && <span className="izakaya-post-new"> NEW!</span>}
        </div>
        <div className="izakaya-td-excerpt">{post.excerpt}</div>
      </td>
      <td className="izakaya-td-tags">
        {post.tags.map((tag, i) => (
          <span key={tag}>
            {i > 0 && " "}
            <button onClick={() => onSelectTag(tag)}>{tag}</button>
          </span>
        ))}
      </td>
    </tr>
  );
}
