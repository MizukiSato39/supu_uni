import type { BlogPost } from "../data/blog-data";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface SidebarProps {
  posts: BlogPost[];
  allTags: string[];
  onSelectTag: (tag: string) => void;
  profileImage: string;
}

export function IzakayaSidebar({ posts, allTags, onSelectTag, profileImage }: SidebarProps) {
  const recentPosts = posts.slice(0, 8);

  const tagCounts: Record<string, number> = {};
  posts.forEach((post) =>
    post.tags.forEach((tag) => {
      tagCounts[tag] = (tagCounts[tag] || 0) + 1;
    })
  );

  // 7日以内の記事か
  const isNew = (dateStr: string) => {
    const d = new Date(dateStr);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return d > weekAgo;
  };

  // カレンダー生成
  const now = new Date();
  const year = 2026;
  const month = 2;
  const firstDay = new Date(year, month - 1, 1).getDay();
  const daysInMonth = new Date(year, month, 0).getDate();
  const postDates = new Set(posts.map(p => new Date(p.date).getDate()));

  const calWeeks: (number | null)[][] = [];
  let week: (number | null)[] = Array(firstDay).fill(null);
  for (let d = 1; d <= daysInMonth; d++) {
    week.push(d);
    if (week.length === 7) {
      calWeeks.push(week);
      week = [];
    }
  }
  if (week.length > 0) {
    while (week.length < 7) week.push(null);
    calWeeks.push(week);
  }

  return (
    <div className="izakaya-sidebar">
      {/* プロフィール */}
      <div className="izakaya-sb-section">
        <div className="izakaya-sb-heading">■ プロフィール</div>
        <div className="izakaya-profile">
          <ImageWithFallback
            src={profileImage}
            alt="プロフィール"
            style={{ width: 80, height: 80, objectFit: "cover", border: "1px solid #ccc" }}
          />
          <div className="izakaya-profile-name">レン・カワセ</div>
          <div className="izakaya-profile-text">
            惑星「春星」出身。地球の食文化に魅了され居酒屋ブログを運営中。趣味は蔵元めぐりと星空観察。(ﾟ∀ﾟ)
          </div>
        </div>
      </div>

      {/* カウンター */}
      <div className="izakaya-sb-section">
        <div className="izakaya-sb-heading">■ アクセスカウンター</div>
        <div className="izakaya-counter-box">
          あなたは<br />
          <span className="izakaya-counter-num">004869</span><br />
          人目のお客様です
        </div>
      </div>

      {/* カレンダー */}
      <div className="izakaya-sb-section">
        <div className="izakaya-sb-heading-blue">■ カレンダー</div>
        <div className="izakaya-calendar">
          <table className="izakaya-cal-table">
            <caption>{year}年{month}月</caption>
            <thead>
              <tr>
                <th className="sun">日</th>
                <th>月</th>
                <th>火</th>
                <th>水</th>
                <th>木</th>
                <th>金</th>
                <th className="sat">土</th>
              </tr>
            </thead>
            <tbody>
              {calWeeks.map((w, wi) => (
                <tr key={wi}>
                  {w.map((d, di) => (
                    <td
                      key={di}
                      className={`${d && postDates.has(d) ? "has-post" : ""} ${di === 0 ? "sun" : ""} ${di === 6 ? "sat" : ""}`}
                    >
                      {d ? (
                        postDates.has(d) ? (
                          <a href="#">{d}</a>
                        ) : (
                          d
                        )
                      ) : (
                        ""
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 最近の記事 */}
      <div className="izakaya-sb-section">
        <div className="izakaya-sb-heading">■ 最近の記事</div>
        <ul className="izakaya-recent-list">
          {recentPosts.map((post) => (
            <li key={post.id} className="izakaya-recent-item">
              <a href="#" className="izakaya-recent-link">
                {post.emoji}{post.title}
              </a>
              {isNew(post.date) && <span className="izakaya-new-gif">NEW!</span>}
              <span className="izakaya-recent-date">{post.date}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* カテゴリ */}
      <div className="izakaya-sb-section">
        <div className="izakaya-sb-heading-green">■ カテゴリ</div>
        <ul className="izakaya-cat-list">
          {allTags.map((tag) => (
            <li key={tag} className="izakaya-cat-item">
              <a href="#" onClick={(e) => { e.preventDefault(); onSelectTag(tag); }}>
                {tag}
              </a>
              <span className="izakaya-cat-count"> ({tagCounts[tag]})</span>
            </li>
          ))}
        </ul>
      </div>

      {/* リンク集 */}
      <div className="izakaya-sb-section">
        <div className="izakaya-sb-heading-blue">■ お気に入り</div>
        <ul className="izakaya-link-list">
          <li className="izakaya-link-item">
            <a href="#">居酒屋めぐり同好会</a>
          </li>
          <li className="izakaya-link-item">
            <a href="#">宇宙旅行ガイド★</a>
          </li>
          <li className="izakaya-link-item">
            <a href="#">全国蔵元マップ</a>
          </li>
          <li className="izakaya-link-item">
            <a href="#">楽天市場で買い物♪</a>
          </li>
          <li className="izakaya-link-item">
            <a href="#">フリー素材屋さん</a>
          </li>
        </ul>
      </div>
    </div>
  );
}
