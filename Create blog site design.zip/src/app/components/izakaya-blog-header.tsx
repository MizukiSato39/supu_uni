import type { BlogConfig } from "../data/blog-data";

interface BlogHeaderProps {
  config: BlogConfig;
  postCount: number;
  latestDate: string;
}

export function IzakayaBlogHeader({ config, postCount, latestDate }: BlogHeaderProps) {
  return (
    <div className="izakaya-blog-head">
      <div className="izakaya-blog-title">
        {config.blogEmoji} {config.blogTitle}
      </div>
      <div className="izakaya-blog-desc">
        {config.blogDesc}
      </div>
      <div className="izakaya-blog-info">
        著者: {config.blogAuthor} / {config.planetJa}({config.planetEn}) |
        記事数: <b style={{ color: "#cc0000" }}>{postCount}</b> |
        最終更新: {latestDate}
      </div>
    </div>
  );
}
