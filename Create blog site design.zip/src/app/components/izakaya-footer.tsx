export function IzakayaFooter() {
  return (
    <div className="izakaya-footer">
      <div className="izakaya-footer-copy">
        Copyright (c) 2025-2026 レン・カワセ All Rights Reserved.
      </div>
      <div className="izakaya-footer-links">
        <a href="#">トップ</a>|
        <a href="#">日記</a>|
        <a href="#">プロフィール</a>|
        <a href="#">掲示板</a>
      </div>
      <div className="izakaya-footer-deco">
        ★☆★☆★☆★☆★
      </div>
    </div>
  );
}
