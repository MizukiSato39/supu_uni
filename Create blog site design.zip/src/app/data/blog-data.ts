export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  tags: string[];
  emoji: string;
  image: string;
  readTime: string;
}

export interface BlogConfig {
  blogTitle: string;
  blogDesc: string;
  blogEmoji: string;
  blogAuthor: string;
  planetJa: string;
  planetEn: string;
}

export const blogConfig: BlogConfig = {
  blogTitle: "居酒屋スプリング日記",
  blogDesc: "宇宙の片隅にある小さな居酒屋から、日々のつれづれを綴ります。美味しいもの、旅の思い出、星空の下で考えたこと。",
  blogEmoji: "🏮",
  blogAuthor: "レン・カワセ",
  planetJa: "春星",
  planetEn: "Harusei",
};

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "春の居酒屋めぐり〜東京下町編〜",
    excerpt: "桜の季節に合わせて、東京下町の老舗居酒屋を巡ってきました。浅草、上野、谷根千エリアの隠れた名店をご紹介します。どのお店も温かい雰囲気で迎えてくれました。",
    date: "2026-02-15",
    tags: ["グルメ", "居酒屋", "東京", "お花見"],
    emoji: "🌸",
    image: "https://images.unsplash.com/photo-1725304406314-0ff876c03ec0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMGl6YWtheWElMjByZXN0YXVyYW50JTIwbmlnaHR8ZW58MXx8fHwxNzcxNDU2MTA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "5分",
  },
  {
    id: 2,
    title: "自家製ラーメンへの挑戦",
    excerpt: "ついに念願の自家製ラーメンに挑戦！豚骨スープを12時間煮込み、自家製麺も作ってみました。結果は…？写真多めでレポートします。",
    date: "2026-02-10",
    tags: ["グルメ", "料理", "ラーメン"],
    emoji: "🍜",
    image: "https://images.unsplash.com/photo-1627900440398-5db32dba8db1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHJhbWVuJTIwbm9vZGxlcyUyMGJvd2x8ZW58MXx8fHwxNzcxNDI1NDg4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "8分",
  },
  {
    id: 3,
    title: "お寿司の美学〜築地の朝〜",
    excerpt: "早朝の築地で新鮮なネタを仕入れ、寿司職人さんの技を間近で拝見。一貫一貫に込められた想いと技術に感動しました。",
    date: "2026-02-05",
    tags: ["グルメ", "寿司", "築地"],
    emoji: "🍣",
    image: "https://images.unsplash.com/photo-1666405483372-5cd114fc8166?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHN1c2hpJTIwcGxhdGV8ZW58MXx8fHwxNzcxNDU2MTA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "6分",
  },
  {
    id: 4,
    title: "焼き鳥の極意を学ぶ",
    excerpt: "名店の焼き鳥職人に密着取材。炭火の温度管理、串打ちのコツ、タレの秘密まで、プロの技を余すところなくお伝えします。",
    date: "2026-01-28",
    tags: ["グルメ", "居酒屋", "焼き鳥"],
    emoji: "🍢",
    image: "https://images.unsplash.com/photo-1768162125959-8a35d4ede7dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHlha2l0b3JpJTIwZ3JpbGxlZCUyMGNoaWNrZW58ZW58MXx8fHwxNzcxNDU2MTA5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "7分",
  },
  {
    id: 5,
    title: "日本酒の世界〜新潟の蔵元を訪ねて〜",
    excerpt: "新潟の老舗蔵元を訪問。杜氏さんから直接お話を聞き、仕込みの現場を見学。お土産に買った限定酒のレビューもあります。",
    date: "2026-01-20",
    tags: ["日本酒", "旅行", "新潟"],
    emoji: "🍶",
    image: "https://images.unsplash.com/photo-1691432633040-c31b6086742c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHNha2UlMjBib3R0bGUlMjBjdXBzfGVufDF8fHx8MTc3MTQ1NjEwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "10分",
  },
  {
    id: 6,
    title: "天ぷらの名店で至福のひととき",
    excerpt: "銀座の天ぷら専門店でカウンター席に座り、揚げたてを一品ずつ堪能。衣のサクサク感と素材の味わいが絶妙でした。",
    date: "2026-01-15",
    tags: ["グルメ", "天ぷら", "銀座"],
    emoji: "🦐",
    image: "https://images.unsplash.com/photo-1763905145546-60bacfea6c9f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHRlbXB1cmElMjBwbGF0ZXxlbnwxfHx8fDE3NzE0NTYxMTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "5分",
  },
  {
    id: 7,
    title: "春星から見た桜の銀河",
    excerpt: "惑星・春星（Harusei）の展望台から眺めた桜の銀河。宇宙に咲く桜は地球のものとはまた違った美しさがありました。",
    date: "2026-01-10",
    tags: ["宇宙", "お花見", "春星"],
    emoji: "🪐",
    image: "https://images.unsplash.com/photo-1647143132421-5a720b181329?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMGNoZXJyeSUyMGJsb3Nzb20lMjBzcHJpbmd8ZW58MXx8fHwxNzcxNDU2MTEwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "4分",
  },
  {
    id: 8,
    title: "禅庭園で心を整える",
    excerpt: "京都の名刹で枯山水の庭園を眺めながら、心を落ち着ける時間を過ごしました。静寂の中で感じたことを書き留めます。",
    date: "2026-01-05",
    tags: ["旅行", "京都", "癒し"],
    emoji: "🧘",
    image: "https://images.unsplash.com/photo-1701738504681-24dc50595e94?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMGdhcmRlbiUyMHplbiUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3NzE0NTYxMTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "6分",
  },
  {
    id: 9,
    title: "屋台グルメ食べ歩き〜福岡の夜〜",
    excerpt: "福岡の中洲で屋台グルメを満喫！博多ラーメン、もつ鍋、餃子、焼き鳥…一晩で何軒はしごしたか覚えていません（笑）",
    date: "2025-12-28",
    tags: ["グルメ", "旅行", "福岡", "屋台"],
    emoji: "🏮",
    image: "https://images.unsplash.com/photo-1614829232481-849218a1e3db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHN0cmVldCUyMGZvb2QlMjBmZXN0aXZhbHxlbnwxfHx8fDE3NzE0NTYxMTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "7分",
  },
  {
    id: 10,
    title: "抹茶の奥深い世界",
    excerpt: "宇治の茶園を訪ね、抹茶の製造工程を見学。茶道体験も初挑戦し、一服の中に込められた日本文化の深さを実感しました。",
    date: "2025-12-20",
    tags: ["グルメ", "旅行", "京都", "お茶"],
    emoji: "🍵",
    image: "https://images.unsplash.com/photo-1613641014814-498411d28156?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMG1hdGNoYSUyMGdyZWVuJTIwdGVhfGVufDF8fHx8MTc3MTQ1NjExMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    readTime: "8分",
  },
];

export function getAllTags(posts: BlogPost[]): string[] {
  const tagSet = new Set<string>();
  posts.forEach((post) => post.tags.forEach((tag) => tagSet.add(tag)));
  return Array.from(tagSet).sort();
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const weekdays = ["日", "月", "火", "水", "木", "金", "土"];
  const weekday = weekdays[date.getDay()];
  return `${year}年${month}月${day}日（${weekday}）`;
}
